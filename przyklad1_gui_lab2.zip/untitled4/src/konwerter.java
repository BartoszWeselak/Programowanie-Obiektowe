import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class konwerter extends JFrame{
    private JTextField CelsjuszTextField;
    private JTextField FarenheitTextField;
    private JButton KonwertujButton;
    private JButton WyczyscButton;
    private JButton WyjdzButton;
    private JRadioButton czcionkaMalaRadioButton;
    private JRadioButton czcionkaSredniaRadioButton;
    private JRadioButton czcionkaDuzaRadioButton;
    private JCheckBox wielkieLiteryCheckBox;
    private JButton resetujButton;
    private JPanel Main;
    private double tempC,tempF;

    public konwerter(){
          super("konwersja celsjusz na farenheit");
          this.setContentPane(this.Main);
          this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.pack();
    setLayout(null);




ActionListener listener=new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {

        Object ob1 = e.getSource();
        if (ob1 == KonwertujButton || ob1 == CelsjuszTextField) {
            tempC = Double.parseDouble(CelsjuszTextField.getText());
            tempF = 32.00 + (9.0 / 5.0) * tempC;
            FarenheitTextField.setText(String.valueOf(tempF));
        }else if(ob1 == WyczyscButton){
            FarenheitTextField.setText("");
            CelsjuszTextField.setText("");
            if(wielkieLiteryCheckBox.isSelected()==true) wielkieLiteryCheckBox.setSelected(false);
        else if(czcionkaDuzaRadioButton.isSelected()==true) czcionkaDuzaRadioButton.setSelected(false);
        else if(czcionkaMalaRadioButton.isSelected()==true) czcionkaMalaRadioButton.setSelected(false);
        else if(czcionkaSredniaRadioButton.isSelected()==true)czcionkaSredniaRadioButton.setSelected(false);


        } else if(ob1==WyjdzButton){
            dispose();
        }else if(ob1==wielkieLiteryCheckBox){

            if(wielkieLiteryCheckBox.isSelected()==true){
                FarenheitTextField.setFont(new Font("SansSerif",Font.BOLD,18));
            }else{

                FarenheitTextField.setFont(new Font("SansSerif",Font.PLAIN,12));
            }


        }else if(ob1==czcionkaMalaRadioButton){

            FarenheitTextField.setFont(new Font("SansSerif",Font.PLAIN,8));
        }else if(ob1==czcionkaSredniaRadioButton){

            FarenheitTextField.setFont(new Font("SansSerif",Font.PLAIN,12));
        }else if(ob1==czcionkaDuzaRadioButton){

            FarenheitTextField.setFont(new Font("SansSerif",Font.PLAIN,20));
        }





    }
    };
        KonwertujButton.addActionListener(listener);
        WyczyscButton.addActionListener(listener);
    WyjdzButton.addActionListener(listener);
    wielkieLiteryCheckBox.addActionListener(listener);
    czcionkaMalaRadioButton.addActionListener(listener);
    czcionkaSredniaRadioButton.addActionListener(listener);
    czcionkaDuzaRadioButton.addActionListener(listener);



    }




    public static void main(String[] args) {
    konwerter conTemp = new konwerter();
    conTemp.setVisible(true);
    }





}