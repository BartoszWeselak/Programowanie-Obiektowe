import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class kalkulator extends JFrame{
    private JPanel panel1;
    private JRadioButton kwadratRadioButton;
    private JRadioButton prostokatRadioButton;
    private JRadioButton trojkatRadioButton;
    private JRadioButton trapezRadioButton;
    private JRadioButton szescianRadioButton;
    private JRadioButton prostopadloscianRadioButton;
    private JRadioButton walecRadioButton;
    private JRadioButton kulaRadioButton;
    private JButton obliczButton;
    private JButton wyczyscButton;
    private JTextField bokatextField;
    private JTextField bokbtextField;
    private JTextField wysokosctextField;
    private JTextField promientextField;
    private JTextField poletextField;
    private JTextField obwodtextField;
    private JTextField objetosctextField;
    double a,b,pole,obwod,objetosc,h,r;
    public kalkulator(){
        super("KALK" );
        this.setContentPane(panel1);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
       setLayout(null);

        bokatextField.setEnabled(false);
        bokbtextField.setEnabled(false);
        promientextField.setEnabled(false);
        wysokosctextField.setEnabled(false);
        poletextField.setEnabled(false);
        obwodtextField.setEnabled(false);
        objetosctextField.setEnabled(false);


        ActionListener listener =new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               Object select = e.getSource();


               if(select==obliczButton){
                   if(kwadratRadioButton.isSelected()==true){
                       a=Double.parseDouble(bokatextField.getText());
                       obwod=a*4;
                       pole =a*a;
                       obwodtextField.setText(""+obwod);
                       poletextField.setText(""+pole);
                   }else if(prostokatRadioButton.isSelected()==true){
                       a=Double.parseDouble(bokatextField.getText());
                       b=Double.parseDouble(bokbtextField.getText());
                       obwod=a*b;
                       pole =a*2+b*2;
                       obwodtextField.setText(""+obwod);
                       poletextField.setText(""+pole);
                  }else if(trojkatRadioButton.isSelected()==true){
                       h=Double.parseDouble(wysokosctextField.getText());

                       a=Double.parseDouble(bokatextField.getText());
                       obwod=a*3;
                       pole=(a*h)/2;
                       obwodtextField.setText(""+obwod);
                       poletextField.setText(""+pole);


                   }else if(trapezRadioButton.isSelected()==true){

                       h=Double.parseDouble(wysokosctextField.getText());
                       b=Double.parseDouble(bokbtextField.getText());
                       a=Double.parseDouble(bokatextField.getText());


                       obwod=2*a+2*b;
                       pole=((a+b)/2)*h;
                       obwodtextField.setText(""+obwod);
                       poletextField.setText(""+pole);

                   }else if(szescianRadioButton.isSelected()==true){
                       a=Double.parseDouble(bokatextField.getText());
                       pole=(a*a)*6;
                       objetosc=a*3;
                       poletextField.setText(""+pole);
                       objetosctextField.setText(""+objetosc);
                   }else if(prostopadloscianRadioButton.isSelected()==true){
                       a=Double.parseDouble(bokatextField.getText());
                       b=Double.parseDouble(bokbtextField.getText());
                       h=Double.parseDouble(wysokosctextField.getText());


                       objetosc=a*b*h;
                       pole=2*(a*b)+2*(a*h)+2*(b*h);

                       poletextField.setText(""+pole);
                       objetosctextField.setText(""+objetosc);


                   }else if(walecRadioButton.isSelected()==true){
                       r=Double.parseDouble(promientextField.getText());
                       h=Double.parseDouble(wysokosctextField.getText());
                        objetosc=Math.PI*(r*r)*h;

                        pole=(2*Math.PI*(r*r))+(2*Math.PI*r*h);
                       poletextField.setText(""+pole);
                       objetosctextField.setText(""+objetosc);

                   }else if(kulaRadioButton.isSelected()==true){
                       r=Double.parseDouble(promientextField.getText());

                       objetosc=(4/3)*Math.PI*Math.pow(r,3);
                       pole=Math.PI*Math.pow(r,2);
                       poletextField.setText(""+pole);
                       objetosctextField.setText(""+objetosc);

                   }

                   }else if(select == wyczyscButton){
                   obwodtextField.setText("");
                   poletextField.setText("");
                   bokbtextField.setText("");
                   bokatextField.setText("");
                   promientextField.setText("");
                   objetosctextField.setText("");
                   wysokosctextField.setText("");

                   prostokatRadioButton.setSelected(false);
                   trapezRadioButton.setSelected(false);
                   trojkatRadioButton.setSelected(false);
                   szescianRadioButton.setSelected(false);
                   walecRadioButton.setSelected(false);
                   kulaRadioButton.setSelected(false);
                   kwadratRadioButton.setSelected(false);
                   prostopadloscianRadioButton.setSelected(false);

                   bokatextField.setEnabled(false);
                   bokbtextField.setEnabled(false);
                   promientextField.setEnabled(false);
                   wysokosctextField.setEnabled(false);
                   poletextField.setEnabled(false);
                   obwodtextField.setEnabled(false);
                   objetosctextField.setEnabled(false);
               }

               if(select==kwadratRadioButton){
                   prostokatRadioButton.setSelected(false);
                   trapezRadioButton.setSelected(false);
                   trojkatRadioButton.setSelected(false);
                   szescianRadioButton.setSelected(false);
                   walecRadioButton.setSelected(false);
                   kulaRadioButton.setSelected(false);
                   prostopadloscianRadioButton.setSelected(false);
                   bokatextField.setEnabled(true);
                   bokbtextField.setEnabled(false);
                   promientextField.setEnabled(false);
                   wysokosctextField.setEnabled(false);
                   poletextField.setEnabled(true);
                   obwodtextField.setEnabled(true);
                   objetosctextField.setEnabled(false);
               }else  if(select==prostokatRadioButton){
                   trapezRadioButton.setSelected(false);
                   trojkatRadioButton.setSelected(false);
                   szescianRadioButton.setSelected(false);
                   walecRadioButton.setSelected(false);
                   kulaRadioButton.setSelected(false);
                   prostopadloscianRadioButton.setSelected(false);
                   kwadratRadioButton.setSelected(false);

                   bokatextField.setEnabled(true);
                   bokbtextField.setEnabled(true);
                   promientextField.setEnabled(false);
                   wysokosctextField.setEnabled(false);
                   poletextField.setEnabled(true);
                   obwodtextField.setEnabled(true);
                   objetosctextField.setEnabled(false);


               }else if(select==trojkatRadioButton){

                   prostokatRadioButton.setSelected(false);
                   trapezRadioButton.setSelected(false);
                   szescianRadioButton.setSelected(false);
                   walecRadioButton.setSelected(false);
                   kulaRadioButton.setSelected(false);
                   prostopadloscianRadioButton.setSelected(false);
                   kwadratRadioButton.setSelected(false);


                   bokatextField.setEnabled(true);
                   bokbtextField.setEnabled(false);
                   promientextField.setEnabled(false);
                   wysokosctextField.setEnabled(true);
                   poletextField.setEnabled(true);
                   obwodtextField.setEnabled(true);
                   objetosctextField.setEnabled(false);


               }else if(select==trapezRadioButton){

                   prostokatRadioButton.setSelected(false);

                   trojkatRadioButton.setSelected(false);
                   szescianRadioButton.setSelected(false);
                   walecRadioButton.setSelected(false);
                   kulaRadioButton.setSelected(false);
                   prostopadloscianRadioButton.setSelected(false);
                   kwadratRadioButton.setSelected(false);



                   bokatextField.setEnabled(true);
                   bokbtextField.setEnabled(true);
                   promientextField.setEnabled(false);
                   wysokosctextField.setEnabled(true);
                   poletextField.setEnabled(true);
                   obwodtextField.setEnabled(true);
                   objetosctextField.setEnabled(false);

               }else if(select==szescianRadioButton){

                   prostokatRadioButton.setSelected(false);
                   trapezRadioButton.setSelected(false);
                   trojkatRadioButton.setSelected(false);

                   walecRadioButton.setSelected(false);
                   kulaRadioButton.setSelected(false);
                   prostopadloscianRadioButton.setSelected(false);
                   kwadratRadioButton.setSelected(false);

                   bokatextField.setEnabled(true);
                   bokbtextField.setEnabled(false);
                   promientextField.setEnabled(false);
                   wysokosctextField.setEnabled(false);
                   poletextField.setEnabled(true);
                   obwodtextField.setEnabled(false);
                   objetosctextField.setEnabled(true);

               }else if(select==walecRadioButton){

                   prostokatRadioButton.setSelected(false);
                   trapezRadioButton.setSelected(false);
                   trojkatRadioButton.setSelected(false);
                   szescianRadioButton.setSelected(false);
                   kulaRadioButton.setSelected(false);
                   prostopadloscianRadioButton.setSelected(false);
                   kwadratRadioButton.setSelected(false);


                   bokatextField.setEnabled(false);
                   bokbtextField.setEnabled(false);
                   promientextField.setEnabled(true);
                   wysokosctextField.setEnabled(true);
                   poletextField.setEnabled(true);
                   obwodtextField.setEnabled(false);
                   objetosctextField.setEnabled(true);

               }else if(select==kulaRadioButton){

                   prostokatRadioButton.setSelected(false);
                   trapezRadioButton.setSelected(false);
                   trojkatRadioButton.setSelected(false);
                   szescianRadioButton.setSelected(false);
                   walecRadioButton.setSelected(false);
                   prostopadloscianRadioButton.setSelected(false);
                   kwadratRadioButton.setSelected(false);


                   bokatextField.setEnabled(false);
                   bokbtextField.setEnabled(false);
                   promientextField.setEnabled(true);
                   wysokosctextField.setEnabled(false);
                   poletextField.setEnabled(true);
                   obwodtextField.setEnabled(false);
                   objetosctextField.setEnabled(true);

               }else if(select==prostopadloscianRadioButton){

                   prostokatRadioButton.setSelected(false);
                   trapezRadioButton.setSelected(false);
                   trojkatRadioButton.setSelected(false);
                   szescianRadioButton.setSelected(false);
                   walecRadioButton.setSelected(false);
                   kulaRadioButton.setSelected(false);
                   kwadratRadioButton.setSelected(false);


                   bokatextField.setEnabled(true);
                   bokbtextField.setEnabled(true);
                   promientextField.setEnabled(true);
                   wysokosctextField.setEnabled(false);
                   poletextField.setEnabled(true);
                   obwodtextField.setEnabled(false);
                   objetosctextField.setEnabled(true);



               }
            }
        };
        obliczButton.addActionListener(listener);
        kwadratRadioButton.addActionListener(listener);
        wyczyscButton.addActionListener(listener);
        prostokatRadioButton.addActionListener(listener);
        kulaRadioButton.addActionListener(listener);
        prostopadloscianRadioButton.addActionListener(listener);
        walecRadioButton.addActionListener(listener);
        szescianRadioButton.addActionListener(listener);
        trojkatRadioButton.addActionListener(listener);
        trapezRadioButton.addActionListener(listener);
    }


    public static void main(String[] args) {
         kalkulator kalku = new kalkulator();
    kalku.setVisible(true);

    }
}























